favorites = []
applyed = []
blank = []

def LA_Fitness():
    print(" ")
    print("LA Fitness: personal Trainer")
    print("Parsippany, NJ")
    print("$12 per hour")
    print("part time")
    favorite = input("would you like to favorite this job(yes or no): ")
    if favorite == "yes":
        print("Job favorited")
        favorites.append("LA Fitness")
    else:
        print("Job not favorited")
    apply_fitness = input("would you like to apply(yes or no): ")
    if apply_fitness == "yes":
        print("Job applyed")
        applyed.append("LA Fitness")
    else:
        print("Job not applyed")
            
def DenvilleDairy():
    print(" ")
    print("Denville Dairy: Crew Member")
    print("Denville, NJ")
    print("$13 per hour")
    print("part time")
    favorite = input("would you like to favorite this job(yes or no): ")
    if favorite == "yes":
        print("Job favorited")
        favorites.append("Denville Dairy")
    else:
        print("Job not favorited")
    apply_Dairy = input("would you like to apply(yes or no): ")
    if apply_Dairy == "yes":
        print("Job applyed")
        applyed.append("Denville Dairy")
    else:
        print("Job not applyed")
            
def Buffalo_Wild_Wings():
    print(" ")
    print("Buffalo Wild Wings: Crew Member")
    print("Hanover, NJ")
    print("$11.50 per hour")
    print("full time")
    favorite = input("would you like to favorite this job(yes or no): ")
    if favorite == "yes":
        print("Job favorited")
        favorites.append("Buffalo Wild Wings")
    else:
        print("Job not favorited")
    apply_Buffalo = input("would you like to apply(yes or no): ")
    if apply_Buffalo == "yes":
        print("Job applyed")    
        applyed.append("Buffalo Wild Wings")
    else:
         print("Job not applyed")
            
def Moes():
    print(" ")
    print("Moes: Cook")
    print("Denville, NJ")
    print("$14.25 per hour")
    print("part time")
    favorite = input("would you like to favorite this job(yes or no): ")
    if favorite == "yes":
        print("Job favorited")
        favorites.append("Moes")
    else:
        print("Job not favorited")
    apply_Moes = input("would you like to apply(yes or no): ")
    if apply_Moes == "yes":
        print("Job applyed")
        applyed.append("Moes")
    else:
        print("Job not applyed")
            
def Tabor():
    print(" ")
    print("Tabor Pizza: Cashier")
    print("Parsippany, NJ")
    print("$13 per hour")
    print("part time")
    favorite = input("would you like to favorite this job(yes or no): ")
    if favorite == "yes":
        print("Job favorited")
        favorites.append("Tabor Pizza")
    else:
        print("Job not favorited")
    apply_Tabor = input("would you like to apply(yes or no): ")
    if apply_Tabor == "yes":
        print("Job applyed")
        applyed.append("Tabor Pizza")
    else:
        print("Job not applyed")
        
def habitburger():
    print(" ")
    print("Habit Burger: Cook")
    print("Parsippany, NJ")
    print("$15 per hour")
    print("full time")
    favorite = input("would you like to favorite this job(yes or no): ")
    if favorite == "yes":
        print("Job favorited")
        favorites.append("Habit Burger")
    else:
        print("Job not favorited")
    apply_Habitburger = input("would you like to apply(yes or no): ")
    if apply_Habitburger == "yes":
        print("Job applyed")
        applyed.append("Habit Burger")
    else:
        print("Job not applyed")
            

while True:
    if favorites == blank:
        print("Favorites: none")
    else:
        print("Favorites: "+str(favorites))
        
    if applyed == blank:
        print("Applyed: none")
    else:
        print("Applyed: "+str(applyed))
    user_job = int(input("search(enter age 15, 16, 17): "))
    if user_job == 15:
        print("RecommendedJobs: LA Fitness, Denville Dairy")
        choice_15 = input("which job do you want to look into: ")
        if choice_15 == "LA Fitness":
            LA_Fitness()
        elif choice_15 == "Denville Dairy":
            DenvilleDairy()
        
    elif user_job == 16:
        print("Recommended Jobs: Buffalo Wild Wings, Moes")
        choice_16 = input("which job do you want to look into: ")
        if choice_16 == "Moes":
            Moes()
        elif choice_16 == "Buffalo Wild Wings":
            Buffalo_Wild_Wings()
            
    elif user_job == 17:
        print("Jobs: Tabor Pizza, Habit Burger")
        choice_16 = input("which job do you want to look into: ")
        if choice_16 == "Tabor Pizza":
            Tabor()
        elif choice_16 == "Habit Burger":
            habitburger()
 
    exit = input("would you like to exit this app(yes or no): ")
    if exit == "yes":
        break
    elif exit == "no":
        print("")
        continue